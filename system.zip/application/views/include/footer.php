
<script src="<?php echo base_url() ?>client-assets/js/jquery-1.11.1.js"></script>
<script src="<?php echo base_url() ?>client-assets/bootstrap/dist/js/bootstrap.min.js"></script>

</body>
</html>
